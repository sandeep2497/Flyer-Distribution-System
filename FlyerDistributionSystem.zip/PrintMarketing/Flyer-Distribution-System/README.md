# Flyer-Distribution-System
Flyer distribution system is a web application, where admins could made the order requests based upon the flyers requested by the customers of various stores.
